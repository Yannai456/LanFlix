Lan flix desktop launcher — Linux

This opens Lan flix in its own window using a browser already on your
device, with no address bar or tabs. It is a small launcher script, not an
installer or a compiled app.

It points at: http://192.168.1.71:8000
If your server's IP address ever changes, restart the Lan flix server once
to regenerate these downloads with the new address.

Move lanflix.desktop into ~/.local/share/applications/ (create that folder if it doesn't exist), then it should appear in your app launcher. You may need to right-click it and choose "Allow launching" the first time.
