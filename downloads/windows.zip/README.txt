Lan flix desktop launcher — Windows

This opens Lan flix in its own window using a browser already on your
device, with no address bar or tabs. It is a small launcher script, not an
installer or a compiled app.

It points at: http://192.168.1.71:8000
If your server's IP address ever changes, restart the Lan flix server once
to regenerate these downloads with the new address.

Double-click lanflix.bat to launch. To pin it, right-click the file, choose "Create shortcut," then drag that shortcut to your taskbar or Start menu.
