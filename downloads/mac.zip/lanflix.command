#!/bin/bash
open -na "Google Chrome" --args --app="http://192.168.1.71:8000" 2>/dev/null || \
open -na "Brave Browser" --args --app="http://192.168.1.71:8000" 2>/dev/null || \
open -na "Microsoft Edge" --args --app="http://192.168.1.71:8000" 2>/dev/null || \
open "http://192.168.1.71:8000"
